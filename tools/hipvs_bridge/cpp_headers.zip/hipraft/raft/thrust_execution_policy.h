// MIT License
//
// Copyright (c) 2024-2025 Advanced Micro Devices, Inc.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#pragma once
#include <thrust/execution_policy.h>

#ifdef __HIP_PLATFORM_AMD__
#ifndef THRUST_EXECUTION_POLICY
#define THRUST_EXECUTION_POLICY thrust::hip_rocprim::par
#endif
#ifndef THRUST_CUDA_CUB_EXECUTE_ON_STREAM_NOSYNC_BASE
#define THRUST_CUDA_CUB_EXECUTE_ON_STREAM_NOSYNC_BASE thrust::hip_rocprim
#endif
#else
#ifndef THRUST_EXECUTION_POLICY
#define THRUST_EXECUTION_POLICY thrust::cuda::par
#endif
#ifndef THRUST_CUDA_CUB_EXECUTE_ON_STREAM_NOSYNC_BASE
#define THRUST_CUDA_CUB_EXECUTE_ON_STREAM_NOSYNC_BASE thrust::cuda_cub
#endif
#endif
